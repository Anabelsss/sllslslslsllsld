"""Just a placeholder to do relative imports"""
# Do not delete this file, it will cause errors.

__author__ = "Dan Gazizullin"
__contact__ = "me@hikariatama.ru"
__copyright__ = "Copyright 2022, Dan Gazizullin"
__credits__ = ["LonamiWebs", "penn5"]
__license__ = "AGPLv3"
__maintainer__ = "developer"
__status__ = "Production"
